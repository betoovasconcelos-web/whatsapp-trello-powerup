/*
 * Gestão no WhatsApp - Power-Up para Trello
 * Lógica principal: define os botões que aparecem no cartão.
 */

// Icone cinzento usado nos botões. Os botões de cartão NÃO devem ter icone colorido.
var WHATSAPP_ICON = 'https://cdn.jsdelivr.net/npm/simple-icons@11/icons/whatsapp.svg';

window.TrelloPowerUp.initialize({
  'card-buttons': function (t, options) {
    return [
      {
        // Botão 1: abre um popup para registar uma nota de contacto
        icon: WHATSAPP_ICON,
        text: 'Registar contacto',
        callback: function (t) {
          return t.popup({
            title: 'Registar contacto WhatsApp',
            url: './contacto.html',
            height: 220
          });
        }
      },
      {
        // Botão 2: abre uma conversa de WhatsApp num separador novo.
        // Lê o numero guardado no cartao; se nao existir, pede para registar primeiro.
        icon: WHATSAPP_ICON,
        text: 'Abrir conversa',
        callback: function (t) {
          return t.get('card', 'shared', 'whatsappNumber')
            .then(function (numero) {
              if (!numero) {
                return t.alert({
                  message: 'Ainda nao ha numero registado. Usa "Registar contacto" primeiro.',
                  duration: 6
                });
              }
              // Remove tudo o que nao seja digito antes de montar o link wa.me
              var limpo = String(numero).replace(/\D/g, '');
              window.open('https://wa.me/' + limpo, '_blank');
            });
        }
      }
    ];
  }
});
