# Gestão no WhatsApp - Power-Up para Trello

Power-Up simples que adiciona dois botões ao cartão do Trello:

- **Registar contacto**: guarda um número de WhatsApp no cartão.
- **Abrir conversa**: abre uma conversa de WhatsApp (wa.me) com esse número.

## Ficheiros

- `index.html` — connector que o Trello carrega no iframe escondido.
- `client.js` — lógica que define os botões.
- `contacto.html` — popup para registar o número.

## Como alojar (GitHub Pages, gratuito)

1. Cria conta em github.com (se ainda não tiveres).
2. Cria um repositório novo, por exemplo `whatsapp-trello-powerup`, marcado como **Public**.
3. Faz upload dos três ficheiros (`index.html`, `client.js`, `contacto.html`).
4. Vai a **Settings > Pages**.
5. Em "Build and deployment", escolhe a branch `main` e a pasta `/ (root)`. Guarda.
6. Aguarda 1-2 minutos. O GitHub mostra o URL final, do tipo:
   `https://o-teu-utilizador.github.io/whatsapp-trello-powerup/`

Esse é o **Iframe connector URL** que colas no formulário do Trello.

## Configurar no Trello

1. Em https://trello.com/power-ups/admin, abre a tua app.
2. No campo "Iframe connector URL", cola o URL do GitHub Pages.
3. Vai ao separador **Capabilities** e ativa **card-buttons**.
4. Guarda.
5. Abre um board no mesmo Workspace, e em Power-Ups > Custom, ativa o teu Power-Up.
6. Abre um cartão: os botões aparecem na secção "Power-Ups" do cartão.
